<?php include('header.php'); ?>
<?php require_once "../assets/php/db/config.php"; ?>
  
<?php include('footer.php'); ?>